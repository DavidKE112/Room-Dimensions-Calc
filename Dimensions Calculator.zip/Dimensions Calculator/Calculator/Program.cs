﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculator
{
    class Program
    {
        static void Main()
        {
            Console.WriteLine("Disclaimer this calculator works in meters. Apoligies for any inconvenience this causes.");

            Console.WriteLine("");

            //User inputs Length in meters
            Console.Write("Please input the length of your room in meters: ");
            decimal lengthSide = decimal.Parse(Console.ReadLine());

            //User inputs Width in meters
            Console.Write("Please input the width of your room in meters: ");
            decimal widthSide = decimal.Parse(Console.ReadLine());

            //User inputs Height in meters
            Console.Write("Please input the height of your room in meters: ");
            decimal heightSide = decimal.Parse(Console.ReadLine());

            //user inputs the Spreading rate of the paint they want to use
            Console.Write("Please input the Spreading rate of the paint you wish to use: ");
            decimal spreadingRate = decimal.Parse(Console.ReadLine());

            //user inputs the number of coats of paint they need to put on the walls
            Console.Write("Please input the number of coats of paint: ");
            decimal noCoats = decimal.Parse(Console.ReadLine());

            Console.WriteLine("");

            //Area = Length * Width
            decimal area = lengthSide * widthSide;
            Console.WriteLine("The Area of the floor is: {0} Meters\u00b2", area);

            //Surface Area = Height * length of each wall added together
            decimal surfaceArea =(((heightSide * widthSide) * 2) + ((heightSide * widthSide) * 2) * 2);

            //(Paint needed Surface Area/Spreading rate) * Number of coats
            decimal paint = (surfaceArea / spreadingRate) * noCoats;
            Console.WriteLine("The amount of paint you will need to paint the walls is: {0} Litres", paint);
            
            //Volume = Length * Width * Height
            decimal volume = lengthSide * widthSide * heightSide;
            Console.WriteLine("The Volume of your room is: {0} Meters\u00b2", volume);

            Console.WriteLine("");

            Console.Write("Would you like do another calculation: ");
            string quit = (Console.ReadLine());

            if(quit == "yes")
            {
                Main();
            }           
        }
    }
}
